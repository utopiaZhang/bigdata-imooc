
$(function(){
var mySwiper = new Swiper ('.swiper-container', {
direction: 'horizontal', // 水平切换选项
loop: true, // 循环模式选项
autoplay: {
	delay: 2000,//2秒切换一次
  },
})

//导航切换
$(".clk").click(function(){
	 var index = $(this).index();
	 $('.clk').each(function(i, item) {	 
	   if (i === index) {
		 $(item).addClass('active')
		   $(".center:eq("+index+")").siblings("div").addClass('ds');
	   } else {
		 $(item).removeClass('active');
		 $(".center:eq("+index+")").removeClass('ds');
		
	   }
	 })
}) 
//底部切换
$(".ck").click(function(){
	var index = $(this).index();
	$('.ck').each(function(i, item) {  
	  if (i === index) {
		$(item).addClass('active1')
	  } else {
		$(item).removeClass('active1');
	   
	  }
	})
}) 
})

//个人详情页
function show(uid) {
	window.open("../show/iframe.html?"+uid,"_self")
}

