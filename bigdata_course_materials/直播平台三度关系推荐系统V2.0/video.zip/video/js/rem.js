//设置rem
function setRem() {
    //ui尺寸
    let uiSize = 750
    //理想视口尺寸
    let winSize = document.documentElement.clientWidth
    //375 iphone6的宽度
    let app = document.getElementById('app')
    //如果视口尺寸大于设计尺寸750时，就显示750宽度范围
    if (winSize > uiSize) {
      app.style.width = uiSize + 'px'
      app.style.margin = '0 auto'
      //app.style.border = '1px solid black'
      return
    }
    if (winSize <= 375) {
      winSize = 375
    }
    //给html元素设置font-size值
    document.documentElement.style.fontSize = winSize / uiSize * 100 + 'px'
    app.style.width = winSize + 'px'
    app.style.border = 'none'
  }
  //当页面加载的时候执行的函数
onload = function() {
    setRem()

	var swiper = new Swiper('.swiper-container', {
		spaceBetween: 20,
		slidesPerView:'auto',
		freeMode: true
	});
	
	var swiperfans = new Swiper('.swiper-container-fans', {
		spaceBetween: 20,
		slidesPerView:'auto',
		freeMode: true
	});
	
	//console.log( $(".fans_list li:nth-child(1)").get());
	$(".fans_list li:nth-child(1)")[0].addEventListener("click",function (e) {
	  $(".swiper-container-fans").hide()
	  $(".swiper-container").toggle(500)
	});
	
	$(".fans_list li:nth-child(2)")[0].addEventListener("click",function (e) {
	  $(".swiper-container").hide()
	  $(".swiper-container-fans").toggle(500)
	});
	
	
	

	$(".back").click(function () {
	  window.open("../show/video.html","_self")
	});
};
  
  //当页面缩放的时候
  onresize = function() {
    setRem()
  }

   